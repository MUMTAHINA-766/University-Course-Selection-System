import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/Login',
    name: 'Login',
    component: () => import('../views/Login.vue')
  },

  {
    path: '/about',
    name: 'About',
    component: () => import('../views/About.vue')
  },
  {
    path: '/index',
    name:'Index',
    component: ()=> import('../views/Index.vue'),
    children:[
      {
        path:'CourseSelection',
        name:'CourseSelection',
        component: () => import('../components/CourseSelection')
      },
      {
        path:'MyClasses',
        name:'MyClasses',
        component: ()=> import('../components/MyClasses')
      },
      {
        path:'Scoring',
        name:'Scoring',
        component:()=> import('../components/Scoring')
      },
      {
        path:'CreateCourse',
        name:'CreateCourse',
        component:()=> import('../components/CreateCourse')
      },
      {
        path:'CreateTeacher',
        name:'CreateTeacher',
        component:()=> import('../components/CreateTeacher')
      },
      {
        path:'CreateClass',
        name:'CreateClass',
        component:()=> import('../components/CreateClass')
      },
      {
        path:'TimeTable',
        name:'TimeTable',
        component:()=> import('../components/TimeTable')
      },
      {
        path:'TeacherTable',
        name:'TeacherTable',
        component:()=> import('../components/TeacherTable')
      },
      {
        path:'Score',
        name:'Score',
        component:()=> import('../components/Score')
      },
      {
        path:'ShowCourse',
        name:'ShowCourse',
        component:()=> import('../components/ShowCourse')
      }

    ]
  }
]

const router = new VueRouter({
  routes
})

export default router
