<template>
  <el-table  :data="loadData"  border>
    <el-table-column
        fixed
        prop="id"
        label="Course ID"
        width="150">
    </el-table-column>
    <el-table-column
        prop="name"
        label="Course Name"
        width="250">
    </el-table-column>
    <el-table-column
        prop="credit"
        label="Course Credit"
        width="150">
    </el-table-column>
    <el-table-column
        fixed="right"
        label="Operation"
        width="250">
      <template slot-scope="scope">
        <el-button @click="handleClick(scope.row)" type="info"><i class="el-icon-zoom-in"></i>view classes</el-button>
      </template>
    </el-table-column>

  </el-table>
</template>

<script>
import axios from "axios"
export default {
  name: "ShowCourse",
  methods: {
    handleClick(row) {
      this.$alert(row, "info");
    },

  },
  mounted() {
    axios.get("http://localhost:9853/api/v1/Course/all").then(response => {
      console.log(response.data);
      this.loadData = response.data;
    })
  },
  data() {
    return {
      loadData: []
    };
  }
}
</script>

<style scoped>

</style>