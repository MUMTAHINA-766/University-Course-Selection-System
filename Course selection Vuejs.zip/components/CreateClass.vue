<template>
<div>

  <el-form ref="form" :model="form" label-width="120px">
    <h2> Create a new Class </h2>


    <el-form-item label="Capacity">
      <el-input v-model="form.capacity"></el-input>
    </el-form-item>
    <el-form-item label="Day">
      <el-input v-model="form.day"></el-input>
    </el-form-item>
    <el-form-item label="Daytime">
      <el-input v-model="form.daytime"></el-input>
    </el-form-item>
    <el-form-item label="Room no">
      <el-input v-model="form.room"></el-input>
    </el-form-item >

    <div class="form-group">
    <el-form-item label="Course ID">
      <el-select v-model="form.course" placeholder="Course ID">
        <el-option
            v-for="item in course"
            :key="item.id"
            :label="item.id"
            :value="item.id">
        </el-option>
      </el-select>
    </el-form-item>
    </div>

    <div class="form-group">
    <el-form-item label="Teacher ID">
    <el-select v-model="form.teacher" placeholder="Teacher ID">
      <el-option
      v-for="item in teacher"
      :key="item.id"
      :label="item.id"
      :value="item.id">
      </el-option>
    </el-select>
    </el-form-item>
    </div>


    <el-form-item>
      <el-button type="primary" @click="onSubmit">Create</el-button>
    </el-form-item>
  </el-form>
</div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'PostFormAxios',
  data(){
    return{
      form: {
        capacity: '',
        day: '',
        daytime:'',
        room:'',
      },
      course:[],
      teacher:[]
    }
  },
  mounted() {
    axios.get("http://localhost:9853/api/v1/Teacher/all").then(response =>{
      this.teacher= response.data;
      axios.get("http://localhost:9853/api/v1/Course/all").then(response =>{
        this.course= response.data;
      })
    })
  },
  methods: {
    onSubmit() {
      axios.post("http://localhost:9853/api/v1/TClass",this.form)
      console.log('submit!');

    }
  },

}
</script>


<style scoped>

</style>