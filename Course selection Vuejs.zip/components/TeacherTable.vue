<template>
  <div id="app">

    <el-row :gutter="20">
      <el-col :span="3"><div class="grid-content bg-purple-dark">Time</div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-dark">Saturday</div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-dark">Sunday</div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-dark">Monday</div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-dark">Tuesday</div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-dark">Wednesday</div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-dark">Thursday</div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-dark">Friday</div></el-col>
    </el-row>
    <el-row :gutter="20">
      <el-col :span="3"><div class="grid-content bg-purple">8.30am-10.10am</div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-light"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-light"></div></el-col>
      <el-col :span="3"><div ref="Tue-8:30" class="grid-content bg-purple"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-light"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple"></div></el-col>
      <el-col :span="3"><div ref="Fri-8:30" class="grid-content bg-purple-light"></div></el-col>
    </el-row >
    <el-row :gutter="20">
      <el-col :span="3"><div class="grid-content bg-purple">10.30am-12.00am</div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-light"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-light"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-light"></div></el-col>
      <el-col :span="3"><div ref="thu-10:30" class="grid-content bg-purple"></div></el-col>
      <el-col :span="3"><div ref="Friday-10:30" class="grid-content bg-purple-light"></div></el-col>
    </el-row>
    <el-row :gutter="20">
      <el-col :span="3"><div class="grid-content bg-purple">2.00pm-3.10pm</div></el-col>
      <el-col :span="3"><div ref="Monday-8:30" class="grid-content bg-purple-light"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-light"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple"></div></el-col>
      <el-col :span="3"><div ref="wed-14:00" class="grid-content bg-purple-light"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-light"></div></el-col>
    </el-row>
    <el-row :gutter="20">
      <el-col :span="3"><div class="grid-content bg-purple">5.00pm-6.40pm</div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-light"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple"></div></el-col>
      <el-col :span="3"><div ref="Monday-5:00" class="grid-content bg-purple-light"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-light"></div></el-col>
      <el-col :span="3"><div ref="Thu-5:00" class="grid-content bg-purple"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-light"></div></el-col>

    </el-row>
    <el-row :gutter="20">
      <el-col :span="3"><div class="grid-content bg-purple">7.00pm-8.40pm</div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-light"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-light"></div></el-col>
      <el-col :span="3"><div ref="Tue-19:00" class="grid-content bg-purple"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-light"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple"></div></el-col>
      <el-col :span="3"><div class="grid-content bg-purple-light"></div></el-col>

    </el-row>
  </div>
</template>

<script>
import axios from "axios"
export default {
  name: "TeacherTable",
  methods: {
  },

  mounted() {
    axios.get("http://localhost:9853/api/v1/Teacher/"+this.$cookies.get("user").id).then(response =>{
      this.loadData = response.data.clses;
      console.log(this.loadData);
      this.loadData.forEach(item => {
        console.log(item.course.name + " " + item.day+"-"+item.daytime);
        this.$refs[item.day+"-"+item.dayTime].innerHTML=item.course.name
            +"</br>" + item.room
            +"</br>" + item.capacity;


      })
    })
  },
  data() {
    return {
      loadData:[]
    };
  }
}
</script>

<style scoped>

#app{
  width: 100%;
}

.el-row {
  margin-bottom: 20px;
}

.el-col {
  border-radius: 4px;
}
.bg-purple-dark {
  background: #99a9bf;
}
.bg-purple {
  background: #d3dce6;
}
.bg-purple-light {
  background: #e5e9f2;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
.row-bg {
  padding: 10px 0;
  background-color: #84aaf1;
}

</style>