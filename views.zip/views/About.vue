<template>
  <div class="about">
    <h1>This is a Demo about the student course selection system (SCSS)</h1>
  </div>
</template>
