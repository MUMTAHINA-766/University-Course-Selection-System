<template>

  <el-form ref="form" :model="form" label-width="120px">
    <h2> Create a new course </h2>
    <form v-on:submit.prevent="submitForm">


      <div class="form-group">
        <label for="name">Course name</label>
        <input type="text" class="form-control" id="name" placeholder="Text"
               v-model="form.name">
      </div>

        <div class="form-group">
          <label for="credit">Course credit</label>
          <input type="text" class="form-control" id="credit" placeholder="Number"
                 v-model="form.credit">
        </div>

        <div class="form-group">
          <button class="btn btn-primary">Submit</button>
        </div>


    </form>
  </el-form>

</template>

<script>
import axios from 'axios';

export default {
  name: 'PostFormAxios',
  data(){
    return{
      form: {
        id:'',
        name: '',
        credit:''

      }
    }
  },
  methods:{
    submitForm(){
      axios.post("http://localhost:9853/api/v1/Course/", this.form)
          .then(() => {
            //Perform Success Action
          })
          .catch(() => {
            // error.response.status Check status code
          }).finally(() => {
        //Perform action in always
      });
    }
  }
}
</script>

