<template>


  <el-form ref="form" :model="form" label-width="120px">
    <h2> Create a new Teacher </h2>



      <el-form-item label="Teacher name">
        <el-input v-model="form.name"></el-input>
      </el-form-item>
      <el-form-item label="Password">
        <el-input v-model="form.pwd"></el-input>
      </el-form-item>
      <el-form-item label="sex">
        <el-input v-model="form.sex"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="onSubmit">Create</el-button>
      </el-form-item>
  </el-form>

</template>

<script>
import axios from 'axios';

export default {
  name: 'PostFormAxios',
  data(){
    return{
      form: {
        name: '',
        pwd: '',
        sex:'',

      }
    }
  },
  methods: {
    onSubmit() {
      axios.post("http://localhost:9853/api/v1/Teacher",this.form)
      console.log('submit!');

    }
  }

}
</script>


<style scoped>

</style>