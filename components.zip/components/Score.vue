<template>
  <el-table  :data="loadData"  border>
    <el-table-column
        fixed
        prop="tclass.id"
        label="Class ID"
        width="150">
    </el-table-column>
    <el-table-column
        prop="tclass.course.name"
        label="Course Name"
        width="250">
    </el-table-column>
    <el-table-column
        prop="tclass.course.credit"
        label="Course Credit"
        width="150">
    </el-table-column>
    <el-table-column
        prop="score"
        label="score"
        width="150">
    </el-table-column>

  </el-table>
</template>

<script>
import axios from "axios"
export default {
  name: "Score",
  methods: {
  },
  mounted() {
    axios.get("http://localhost:9853/api/v1/Student/"+this.$cookies.get("user").id).then(response =>{
      this.loadData = response.data.selections;
          console.log(this.loadData);
          this.loadData.forEach(item => {
            console.log(item.tclass.course.id()+" "+item.tclass.course.name + " " + item.tclass.score);})

    })
  },
  data() {
    return {
      loadData:[]
    };
  }
}
</script>

<style scoped>

</style>