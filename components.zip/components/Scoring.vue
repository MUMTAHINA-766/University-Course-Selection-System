
<template>
  <el-table :data="loadData" border>
    <el-table-column
        fixed
        prop="student.id"
        label="Student ID"
        width="150">
    </el-table-column>
    <el-table-column
        prop="student.name"
        label="Student Name"
        width="250">
    </el-table-column>
    <el-table-column
        prop="score"
        label="Score"
        width="150">
    </el-table-column>

    <el-table-column
        fixed="right"
        label="Operation"
        width="250">
      <template slot-scope="scope">
        <el-button @click="scoring(scope.$index,scope.row)" type="danger"><i class="el-icon-edit"></i>Scoring</el-button>

      </template>
    </el-table-column>
  </el-table>
</template>

<script>
import axios from "axios"
export default {
  name: "Scoring",
  methods: {

    scoring(index,row) {
      this.$prompt('Enter The Score', 'Tips',
          {inputPattern:/^[0-9]*$/,inputErrorMessage:'Type number',
          confirmButtonText:'OK',
          cancelButtonText:'Cancel'})
          .then(({value})=>{

        axios.get("http://localhost:9853/api/v1/TClass/scoring",
            {
              params: {studentid: row.student.id, score: value, clsid: this.$route.query.clsid}
            }).then(response => {
          console.log(response);
          row.score = value;
        })

      });
    }
  },
  mounted() {
    axios.get("http://localhost:9853/api/v1/TClass/"+ this.$route.query.clsid).then(response =>{
      this.loadData = response.data.selections;
    })
  },
  data() {
    return {
      loadData:[]
    };
  }
}
</script>

<style scoped>

</style> 
